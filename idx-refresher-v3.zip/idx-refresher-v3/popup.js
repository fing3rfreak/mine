// Auto Refresher Pro v3 — Popup Logic

let entries = [];

// ── Helpers ───────────────────────────────────────────────────────────────────

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function fmtInterval(seconds) {
  if (seconds < 60) return `${seconds}s`;
  const m = seconds / 60;
  return Number.isInteger(m) ? `${m}m` : `${m.toFixed(1)}m`;
}

function fmtTime(ts) {
  if (!ts) return "never";
  const d = Math.floor((Date.now() - ts) / 1000);
  if (d < 5) return "just now";
  if (d < 60) return `${d}s ago`;
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  return `${Math.floor(d / 3600)}h ago`;
}

function showToast(msg, type = "success") {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = `toast ${type} show`;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 2400);
}

function matchLabel(type) {
  return { exact: "exact", partial: "partial", both: "both" }[type] || type;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function switchToTab(name) {
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
  document.querySelector(`[data-tab="${name}"]`).classList.add("active");
  document.getElementById(`panel-${name}`).classList.add("active");
  if (name === "list") loadEntries();
}

// ── Load & Render ─────────────────────────────────────────────────────────────

function loadEntries() {
  chrome.runtime.sendMessage({ action: "getEntries" }, (res) => {
    entries = res?.entries || [];
    renderList();
    updateStats();
  });
}

function updateStats() {
  const active = entries.filter(e => e.enabled).length;
  document.getElementById("activeCount").textContent = active;
  document.getElementById("totalCount").textContent = entries.length;
  document.getElementById("modalCount").textContent = entries.length;

  // Pulse dot only if any active
  const dot = document.getElementById("activeDot");
  dot.style.background = active > 0 ? "#2563eb" : "#9ca3af";
  dot.style.animation = active > 0 ? "" : "none";
}

function renderList() {
  const container = document.getElementById("entriesList");

  if (entries.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔗</div>
        <div class="empty-title">No URLs yet</div>
        <div class="empty-desc">
          Use <strong>Add URL</strong> to add one,<br>
          or <strong>Import</strong> to load from a file.
        </div>
      </div>`;
    return;
  }

  container.innerHTML = entries.map(e => `
    <div class="entry-card ${e.enabled ? 'is-enabled' : 'is-disabled'}" data-id="${e.id}">
      <div class="entry-main">
        <label class="e-toggle-wrap">
          <input type="checkbox" ${e.enabled ? 'checked' : ''} data-toggle="${e.id}" />
          <span class="e-slider"></span>
        </label>
        <div class="entry-content">
          <div class="entry-name">${escHtml(e.label || e.pattern)}</div>
          <div class="entry-url">${escHtml(e.pattern)}</div>
        </div>
        <div class="entry-badges">
          <span class="badge badge-blue">${fmtInterval(e.intervalSeconds)}</span>
          <span class="badge badge-gray">${matchLabel(e.matchType)}</span>
        </div>
        <div class="entry-btns">
          <button class="action-btn btn-refresh" data-refresh="${e.id}" title="Refresh now">⟳</button>
          <button class="action-btn btn-del" data-delete="${e.id}" title="Delete">🗑</button>
        </div>
      </div>
      <div class="entry-footer">
        <span class="entry-meta-text">Last refreshed: <span>${fmtTime(e.lastRefresh)}</span></span>
        <span class="entry-meta-text"><span>${e.refreshCount || 0}</span> total refreshes</span>
      </div>
    </div>
  `).join("");

  // Toggle enable/disable
  container.querySelectorAll("[data-toggle]").forEach(el => {
    el.addEventListener("change", () => {
      chrome.runtime.sendMessage({ action: "toggleEntry", id: el.dataset.toggle }, () => {
        loadEntries();
        showToast(el.checked ? "✓ Enabled" : "⏸ Paused", el.checked ? "success" : "info");
      });
    });
  });

  // Refresh now
  container.querySelectorAll("[data-refresh]").forEach(el => {
    el.addEventListener("click", () => {
      el.style.transform = "rotate(360deg)";
      el.style.transition = "transform 0.4s";
      setTimeout(() => { el.style.transform = ""; el.style.transition = ""; }, 400);
      chrome.runtime.sendMessage({ action: "refreshNow", id: el.dataset.refresh }, (res) => {
        showToast(`⟳ Refreshed ${res?.count || 0} tab(s)`, "info");
        loadEntries();
      });
    });
  });

  // Delete single
  container.querySelectorAll("[data-delete]").forEach(el => {
    el.addEventListener("click", () => {
      chrome.runtime.sendMessage({ action: "deleteEntry", id: el.dataset.delete }, () => {
        loadEntries();
        showToast("Removed", "error");
      });
    });
  });
}

// ── Tab Switching ─────────────────────────────────────────────────────────────

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => switchToTab(tab.dataset.tab));
});

// ── Add Entry ─────────────────────────────────────────────────────────────────

document.getElementById("addBtn").addEventListener("click", () => {
  const label    = document.getElementById("addLabel").value.trim();
  const pattern  = document.getElementById("addPattern").value.trim();
  const matchType = document.getElementById("addMatchType").value;
  const val      = parseFloat(document.getElementById("addIntervalVal").value) || 30;
  const unit     = document.getElementById("addIntervalUnit").value;

  if (!pattern) { showToast("Enter a URL or pattern", "error"); return; }

  const seconds = unit === "min" ? Math.round(val * 60) : Math.round(val);
  if (seconds < 5) { showToast("Minimum interval is 5 seconds", "error"); return; }

  const newEntry = {
    id: uid(), label: label || pattern, pattern,
    matchType, intervalSeconds: seconds,
    enabled: true, lastRefresh: null, refreshCount: 0
  };

  chrome.runtime.sendMessage({ action: "getEntries" }, (res) => {
    const updated = [...(res?.entries || []), newEntry];
    chrome.runtime.sendMessage({ action: "saveEntries", entries: updated }, () => {
      showToast("✓ Added & started");
      document.getElementById("addLabel").value = "";
      document.getElementById("addPattern").value = "";
      document.getElementById("addIntervalVal").value = "";
      switchToTab("list");
    });
  });
});

// ── Delete All ────────────────────────────────────────────────────────────────

document.getElementById("deleteAllBtn").addEventListener("click", () => {
  if (entries.length === 0) { showToast("Nothing to delete", "info"); return; }
  document.getElementById("deleteAllModal").classList.add("show");
});

document.getElementById("cancelDeleteAll").addEventListener("click", () => {
  document.getElementById("deleteAllModal").classList.remove("show");
});

document.getElementById("confirmDeleteAll").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "saveEntries", entries: [] }, () => {
    document.getElementById("deleteAllModal").classList.remove("show");
    loadEntries();
    showToast("🗑 All URLs deleted", "error");
  });
});

// Close modal on overlay click
document.getElementById("deleteAllModal").addEventListener("click", (e) => {
  if (e.target === e.currentTarget) e.currentTarget.classList.remove("show");
});

// ── Parse Lines ───────────────────────────────────────────────────────────────

function parseLines(text) {
  return text.split("\n")
    .map(l => l.trim())
    .filter(l => l && !l.startsWith("#"))
    .map(line => {
      const parts = line.split(",").map(p => p.trim());
      const pattern = parts[0];
      if (!pattern) return null;
      const intervalRaw = parseFloat(parts[1]) || 30;
      const unit = (parts[2] || "sec").toLowerCase().startsWith("m") ? "min" : "sec";
      const seconds = unit === "min" ? Math.round(intervalRaw * 60) : Math.round(intervalRaw);
      const matchType = (parts[3] || "both").toLowerCase();
      const validMatch = ["exact","partial","both"].includes(matchType) ? matchType : "both";
      const label = parts[4] || pattern;
      return {
        id: uid(), label, pattern, matchType: validMatch,
        intervalSeconds: Math.max(5, seconds),
        enabled: true, lastRefresh: null, refreshCount: 0
      };
    })
    .filter(Boolean);
}

// ── Import ────────────────────────────────────────────────────────────────────

document.getElementById("importBtn").addEventListener("click", () => {
  const text = document.getElementById("pasteArea").value;
  if (!text.trim()) { showToast("Nothing to import", "error"); return; }
  doImport(text);
});

function doImport(text) {
  const newEntries = parseLines(text);
  if (!newEntries.length) { showToast("No valid entries found", "error"); return; }

  chrome.runtime.sendMessage({ action: "getEntries" }, (res) => {
    const merged = [...(res?.entries || []), ...newEntries];
    chrome.runtime.sendMessage({ action: "saveEntries", entries: merged }, () => {
      showToast(`✓ Imported ${newEntries.length} URL(s)`);
      document.getElementById("pasteArea").value = "";
      switchToTab("list");
    });
  });
}

document.getElementById("fileInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => doImport(ev.target.result);
  reader.readAsText(file);
  e.target.value = "";
});

const dropZone = document.getElementById("dropZone");
dropZone.addEventListener("dragover", (e) => { e.preventDefault(); dropZone.classList.add("dragover"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
dropZone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropZone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => doImport(ev.target.result);
  reader.readAsText(file);
});

// ── Auto-refresh display every 4s ─────────────────────────────────────────────

setInterval(() => {
  if (document.querySelector("[data-tab='list']").classList.contains("active")) {
    loadEntries();
  }
}, 4000);

// ── Init ──────────────────────────────────────────────────────────────────────
loadEntries();
