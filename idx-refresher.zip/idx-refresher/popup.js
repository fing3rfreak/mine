// popup.js — IDX Auto Refresher UI Logic

const enableToggle = document.getElementById("enableToggle");
const toggleLabel = document.getElementById("toggleLabel");
const statusDot = document.getElementById("statusDot");
const intervalDisplay = document.getElementById("intervalDisplay");
const lastRefreshText = document.getElementById("lastRefreshText");
const customValue = document.getElementById("customValue");
const unitSelect = document.getElementById("unitSelect");
const setCustomBtn = document.getElementById("setCustomBtn");
const refreshNowBtn = document.getElementById("refreshNowBtn");
const toastEl = document.getElementById("toast");
const presetBtns = document.querySelectorAll(".preset-btn");

let currentSeconds = 30;

function showToast(msg, color = "#00ff88") {
  toastEl.textContent = msg;
  toastEl.style.background = color;
  toastEl.style.color = color === "#00ff88" ? "#000" : "#fff";
  toastEl.classList.add("show");
  setTimeout(() => toastEl.classList.remove("show"), 2000);
}

function formatInterval(seconds) {
  if (seconds < 60) return `${seconds}s`;
  const mins = seconds / 60;
  return Number.isInteger(mins) ? `${mins}m` : `${(seconds/60).toFixed(1)}m`;
}

function formatTimeSince(ts) {
  if (!ts) return "never";
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 5) return "just now";
  if (diff < 60) return `${diff}s ago`;
  return `${Math.floor(diff/60)}m ago`;
}

function updateUI(enabled, seconds) {
  enableToggle.checked = enabled;
  toggleLabel.textContent = enabled ? "ON" : "OFF";
  statusDot.classList.toggle("active", enabled);
  intervalDisplay.textContent = formatInterval(seconds);
  currentSeconds = seconds;

  presetBtns.forEach(btn => {
    btn.classList.toggle("active", parseInt(btn.dataset.sec) === seconds);
  });
}

// Load current status
chrome.runtime.sendMessage({ action: "getStatus" }, (data) => {
  if (data) {
    updateUI(data.enabled ?? true, data.intervalSeconds ?? 30);
    lastRefreshText.textContent = formatTimeSince(data.lastRefresh);
  }
});

// Auto-update last refresh display
setInterval(() => {
  chrome.runtime.sendMessage({ action: "getStatus" }, (data) => {
    if (data) lastRefreshText.textContent = formatTimeSince(data.lastRefresh);
  });
}, 3000);

// Toggle enable/disable
enableToggle.addEventListener("change", () => {
  chrome.runtime.sendMessage({ action: "toggle" }, (res) => {
    if (res) {
      updateUI(res.enabled, currentSeconds);
      showToast(res.enabled ? "✓ Refresher enabled" : "⏸ Refresher paused", res.enabled ? "#00ff88" : "#ff4466");
    }
  });
});

// Preset buttons
presetBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    const sec = parseInt(btn.dataset.sec);
    applyInterval(sec);
  });
});

// Custom set button
setCustomBtn.addEventListener("click", () => {
  const val = parseFloat(customValue.value);
  if (!val || val <= 0) {
    showToast("Enter a valid number", "#ff4466");
    return;
  }
  const unit = unitSelect.value;
  const sec = unit === "min" ? Math.round(val * 60) : Math.round(val);
  if (sec < 5) {
    showToast("Min interval is 5 seconds", "#ff4466");
    return;
  }
  applyInterval(sec);
  customValue.value = "";
});

// Allow Enter key on custom input
customValue.addEventListener("keydown", (e) => {
  if (e.key === "Enter") setCustomBtn.click();
});

function applyInterval(seconds) {
  chrome.runtime.sendMessage({ action: "setInterval", seconds }, (res) => {
    if (res?.success) {
      updateUI(true, seconds);
      showToast(`✓ Interval set to ${formatInterval(seconds)}`);
    }
  });
}

// Refresh now
refreshNowBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "refreshNow" }, () => {
    showToast("⟳ Refreshed IDX tabs!");
    lastRefreshText.textContent = "just now";
  });
});
