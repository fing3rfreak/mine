// IDX Auto Refresher - Background Service Worker
// Starts automatically on browser launch via chrome.runtime.onStartup

const ALARM_NAME = "idx-refresher";
const DEFAULT_INTERVAL_SECONDS = 30;
const IDX_PATTERN = "idx.google.com";

// --- Initialization ---

// On browser startup - auto start without any user interaction
chrome.runtime.onStartup.addListener(() => {
  initRefresher();
});

// On extension install / update
chrome.runtime.onInstalled.addListener(() => {
  initRefresher();
});

async function initRefresher() {
  const data = await chrome.storage.local.get(["intervalSeconds", "enabled"]);
  const intervalSeconds = data.intervalSeconds ?? DEFAULT_INTERVAL_SECONDS;
  const enabled = data.enabled ?? true;

  // Save defaults if not set
  if (data.intervalSeconds === undefined) {
    await chrome.storage.local.set({ intervalSeconds: DEFAULT_INTERVAL_SECONDS });
  }
  if (data.enabled === undefined) {
    await chrome.storage.local.set({ enabled: true });
  }

  if (enabled) {
    scheduleAlarm(intervalSeconds);
  }
}

// --- Alarm Scheduling ---

function scheduleAlarm(intervalSeconds) {
  // Chrome alarms minimum is 1 minute (60 seconds) for periodInMinutes.
  // For sub-minute intervals, we use a workaround via repeated single alarms.
  chrome.alarms.clear(ALARM_NAME, () => {
    if (intervalSeconds >= 60) {
      chrome.alarms.create(ALARM_NAME, {
        delayInMinutes: intervalSeconds / 60,
        periodInMinutes: intervalSeconds / 60
      });
    } else {
      // For sub-minute, use minimum 0.5 min (30s) via single-shot re-scheduling
      chrome.alarms.create(ALARM_NAME, {
        delayInMinutes: intervalSeconds / 60,
        periodInMinutes: intervalSeconds / 60  // Chrome clamps to minimum ~0.5 min internally
      });
    }
  });
}

// --- Alarm Handler ---

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;

  const data = await chrome.storage.local.get(["enabled"]);
  if (!data.enabled) return;

  refreshIDXTabs();
});

// --- Tab Refresher ---

async function refreshIDXTabs() {
  const tabs = await chrome.tabs.query({});
  let refreshed = 0;

  for (const tab of tabs) {
    if (tab.url && tab.url.includes(IDX_PATTERN)) {
      try {
        await chrome.tabs.reload(tab.id);
        refreshed++;
      } catch (e) {
        console.warn("Could not reload tab:", tab.id, e);
      }
    }
  }

  // Update last refresh timestamp
  await chrome.storage.local.set({
    lastRefresh: Date.now(),
    lastRefreshCount: refreshed
  });

  console.log(`[IDX Refresher] Refreshed ${refreshed} tab(s) at ${new Date().toLocaleTimeString()}`);
}

// --- Message Handler (from popup) ---

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "setInterval") {
    const seconds = message.seconds;
    chrome.storage.local.set({ intervalSeconds: seconds }, () => {
      scheduleAlarm(seconds);
      sendResponse({ success: true });
    });
    return true; // async response
  }

  if (message.action === "toggle") {
    chrome.storage.local.get(["intervalSeconds", "enabled"], (data) => {
      const newEnabled = !data.enabled;
      chrome.storage.local.set({ enabled: newEnabled }, () => {
        if (newEnabled) {
          scheduleAlarm(data.intervalSeconds ?? DEFAULT_INTERVAL_SECONDS);
        } else {
          chrome.alarms.clear(ALARM_NAME);
        }
        sendResponse({ enabled: newEnabled });
      });
    });
    return true;
  }

  if (message.action === "refreshNow") {
    refreshIDXTabs().then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.action === "getStatus") {
    chrome.storage.local.get(["intervalSeconds", "enabled", "lastRefresh", "lastRefreshCount"], (data) => {
      sendResponse(data);
    });
    return true;
  }
});
