// Auto Clicker Pro — Content Script v3
(function () {
  // Clean up previous instance
  document.getElementById("__ac_overlay__")?.remove();
  document.getElementById("__ac_tooltip__")?.remove();
  document.getElementById("__ac_highlight__")?.remove();
  if (window.__acMsgListener) {
    chrome.runtime.onMessage.removeListener(window.__acMsgListener);
  }

  let active = false;
  let overlay, tooltip;

  function onMsg(msg, sender, sendResponse) {
    if (msg.action === "startPicker") { startPicker(); sendResponse({ ok: true }); }
    if (msg.action === "stopPicker")  { stopPicker();  sendResponse({ ok: true }); }
  }
  window.__acMsgListener = onMsg;
  chrome.runtime.onMessage.addListener(onMsg);

  function startPicker() {
    if (active) return;
    active = true;

    // Thin banner at BOTTOM — out of the way, pointer-events only on cancel btn
    overlay = document.createElement("div");
    overlay.id = "__ac_overlay__";
    overlay.style.cssText = `
      position:fixed;bottom:0;left:0;right:0;z-index:2147483647;
      background:linear-gradient(135deg,#7c3aed,#2563eb);
      color:#fff;padding:8px 14px;
      font-family:system-ui,-apple-system,sans-serif;font-size:12px;font-weight:600;
      display:flex;align-items:center;justify-content:space-between;
      box-shadow:0 -2px 12px rgba(0,0,0,.25);
      pointer-events:none;`;          /* ← whole bar is click-through */
    overlay.innerHTML = `
      <span>🎯 Hover &amp; click any element to select it</span>
      <button id="__ac_cancel__" style="
        pointer-events:auto;           
        background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.4);
        color:#fff;padding:3px 10px;border-radius:5px;
        font-size:11px;cursor:pointer;font-weight:600;font-family:inherit">
        ✕ Cancel
      </button>`;
    document.body.appendChild(overlay);

    document.getElementById("__ac_cancel__").addEventListener("click", (e) => {
      e.stopPropagation();
      stopPicker();
      chrome.storage.local.set({ __pickerResult: { cancelled: true, ts: Date.now() } });
    });

    tooltip = document.createElement("div");
    tooltip.id = "__ac_tooltip__";
    tooltip.style.cssText = `
      position:fixed;z-index:2147483646;background:#1e293b;color:#e2e8f0;
      padding:5px 10px;border-radius:6px;font-family:monospace;font-size:11px;
      pointer-events:none;max-width:340px;word-break:break-all;
      box-shadow:0 4px 12px rgba(0,0,0,.4);opacity:0;transition:opacity .1s;`;
    document.body.appendChild(tooltip);

    document.addEventListener("mouseover", onOver,  true);
    document.addEventListener("mouseout",  onOut,   true);
    document.addEventListener("click",     onClick, true);
    document.addEventListener("keydown",   onKey,   true);
  }

  function stopPicker() {
    active = false;
    document.removeEventListener("mouseover", onOver,  true);
    document.removeEventListener("mouseout",  onOut,   true);
    document.removeEventListener("click",     onClick, true);
    document.removeEventListener("keydown",   onKey,   true);
    document.getElementById("__ac_highlight__")?.remove();
    overlay?.remove();  overlay = null;
    tooltip?.remove();  tooltip = null;
  }

  function onOver(e) {
    if (!active) return;
    if (overlay?.contains(e.target)) return;
    document.getElementById("__ac_highlight__")?.remove();
    const rect = e.target.getBoundingClientRect();
    const hl = document.createElement("div");
    hl.id = "__ac_highlight__";
    hl.style.cssText = `
      position:fixed;top:${rect.top}px;left:${rect.left}px;
      width:${rect.width}px;height:${rect.height}px;
      border:2px solid #7c3aed;background:rgba(124,58,237,.12);
      pointer-events:none;z-index:2147483645;border-radius:3px;`;
    document.body.appendChild(hl);
    const sel = getSelector(e.target);
    const txt = e.target.textContent.trim().slice(0, 50);
    tooltip.textContent = sel + (txt ? ` · "${txt}"` : "");
    tooltip.style.opacity = "1";
    // Show tooltip above element; avoid banner at bottom
    const tipTop = rect.top > 50 ? rect.top - 32 : rect.top + rect.height + 6;
    tooltip.style.top  = `${Math.max(4, tipTop)}px`;
    tooltip.style.left = `${Math.min(rect.left, window.innerWidth - 360)}px`;
  }

  function onOut() {
    document.getElementById("__ac_highlight__")?.remove();
    if (tooltip) tooltip.style.opacity = "0";
  }

  function onClick(e) {
    if (!active) return;
    if (overlay?.contains(e.target)) return;
    e.preventDefault();
    e.stopPropagation();
    const selector = getSelector(e.target);
    const text = e.target.textContent.trim().slice(0, 80);
    stopPicker();
    chrome.storage.local.set({
      __pickerResult: { selector, text, ts: Date.now(), cancelled: false }
    });
  }

  function onKey(e) {
    if (e.key === "Escape") {
      stopPicker();
      chrome.storage.local.set({ __pickerResult: { cancelled: true, ts: Date.now() } });
    }
  }

  function getSelector(el) {
    if (el.id && /^[a-z_-][a-z0-9_-]*$/i.test(el.id)) return `#${el.id}`;
    for (const attr of ["data-testid","data-id","name","aria-label"]) {
      const v = el.getAttribute(attr);
      if (v) return `${el.tagName.toLowerCase()}[${attr}="${v}"]`;
    }
    if (el.className && typeof el.className === "string") {
      const cls = el.className.trim().split(/\s+/).filter(c => /^[a-z_-]/i.test(c));
      if (cls.length) {
        const s = el.tagName.toLowerCase() + "." + cls.slice(0,3).join(".");
        try { if (document.querySelectorAll(s).length === 1) return s; } catch {}
      }
    }
    return getNthPath(el);
  }

  function getNthPath(el) {
    const parts = [];
    let node = el;
    while (node && node !== document.body && node.nodeType === 1) {
      let s = node.tagName.toLowerCase();
      if (node.id) { parts.unshift(`#${node.id}`); break; }
      const sibs = Array.from(node.parentNode?.children || []).filter(c => c.tagName === node.tagName);
      if (sibs.length > 1) s += `:nth-of-type(${sibs.indexOf(node)+1})`;
      parts.unshift(s);
      node = node.parentNode;
    }
    return parts.join(" > ");
  }
})();
