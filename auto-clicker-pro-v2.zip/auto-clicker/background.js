// Auto Clicker Pro — Background Service Worker

const ALARM_PREFIX = "autoclicker::seq::";

chrome.runtime.onStartup.addListener(() => scheduleAll());
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get("sequences", ({ sequences }) => {
    if (!sequences) chrome.storage.local.set({ sequences: [] });
  });
});

async function scheduleAll() {
  const { sequences = [] } = await chrome.storage.local.get("sequences");
  await chrome.alarms.clearAll();
  for (const seq of sequences) {
    if (seq.enabled) scheduleAlarm(seq);
  }
}

function scheduleAlarm(seq) {
  const mins = seq.delaySeconds / 60;
  chrome.alarms.create(ALARM_PREFIX + seq.id, { delayInMinutes: Math.max(mins, 0.1) });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith(ALARM_PREFIX)) return;
  const id = alarm.name.slice(ALARM_PREFIX.length);
  const { sequences = [] } = await chrome.storage.local.get("sequences");
  const seq = sequences.find(s => s.id === id);
  if (!seq || !seq.enabled) return;
  await runSequence(seq);
});

async function runSequence(seq) {
  const tabs = await chrome.tabs.query({});
  const tab = tabs.find(t => t.url && t.url.includes(seq.urlPattern));
  if (!tab) { await logResult(seq.id, "error", `No tab found matching "${seq.urlPattern}"`); return; }

  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: runStepsInPage,
      args: [seq.steps, seq.stepDelaySeconds || 1]
    });
    await logResult(seq.id, "success", `Ran ${seq.steps.length} step(s)`);
  } catch (e) {
    await logResult(seq.id, "error", e.message);
  }
}

function runStepsInPage(steps, stepDelaySeconds) {
  return new Promise(async (resolve, reject) => {
    const delay = ms => new Promise(r => setTimeout(r, ms));
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      let el = null;
      const deadline = Date.now() + 5000;
      while (Date.now() < deadline) {
        el = document.querySelector(step.selector);
        if (el) break;
        await delay(200);
      }
      if (!el && step.text) {
        const all = document.querySelectorAll("button, a, [role='button'], input[type='submit']");
        for (const c of all) {
          if (c.textContent.trim().toLowerCase().includes(step.text.toLowerCase())) { el = c; break; }
        }
      }
      if (!el) { reject(new Error(`Step ${i + 1}: Element not found — "${step.selector}"`)); return; }
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      await delay(300);
      el.click();
      if (i < steps.length - 1) await delay(stepDelaySeconds * 1000);
    }
    resolve("done");
  });
}

async function logResult(seqId, status, message) {
  const { sequences = [] } = await chrome.storage.local.get("sequences");
  const updated = sequences.map(s => s.id === seqId
    ? { ...s, lastRun: Date.now(), lastStatus: status, lastMessage: message } : s);
  await chrome.storage.local.set({ sequences: updated });
}

// ── Messages ──────────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === "getSequences") {
    chrome.storage.local.get("sequences", ({ sequences = [] }) => sendResponse({ sequences }));
    return true;
  }

  if (msg.action === "saveSequences") {
    chrome.alarms.clearAll(async () => {
      await chrome.storage.local.set({ sequences: msg.sequences });
      for (const seq of msg.sequences) { if (seq.enabled) scheduleAlarm(seq); }
      sendResponse({ success: true });
    });
    return true;
  }

  if (msg.action === "runNow") {
    chrome.storage.local.get("sequences", async ({ sequences = [] }) => {
      const seq = sequences.find(s => s.id === msg.id);
      if (!seq) { sendResponse({ error: "Not found" }); return; }
      await runSequence(seq);
      chrome.storage.local.get("sequences", ({ sequences: u = [] }) => {
        const s = u.find(x => x.id === msg.id);
        sendResponse({ status: s?.lastStatus, message: s?.lastMessage });
      });
    });
    return true;
  }

  if (msg.action === "toggleSequence") {
    chrome.storage.local.get("sequences", ({ sequences = [] }) => {
      const updated = sequences.map(s => {
        if (s.id !== msg.id) return s;
        const enabled = !s.enabled;
        if (enabled) scheduleAlarm({ ...s, enabled: true });
        else chrome.alarms.clear(ALARM_PREFIX + s.id);
        return { ...s, enabled };
      });
      chrome.storage.local.set({ sequences: updated }, () => sendResponse({ success: true }));
    });
    return true;
  }

  if (msg.action === "deleteSequence") {
    chrome.alarms.clear(ALARM_PREFIX + msg.id);
    chrome.storage.local.get("sequences", ({ sequences = [] }) => {
      const updated = sequences.filter(s => s.id !== msg.id);
      chrome.storage.local.set({ sequences: updated }, () => sendResponse({ success: true }));
    });
    return true;
  }

  // ── Picker: inject into active tab ────────────────────────────────────────
  if (msg.action === "startPicker") {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab) { sendResponse({ error: "No active tab" }); return; }

      const url = tab.url || "";
      if (url.startsWith("chrome://") || url.startsWith("brave://") ||
          url.startsWith("edge://")   || url.startsWith("about:")   ||
          url.startsWith("chrome-extension://") || url === "") {
        sendResponse({ error: "Navigate to a real webpage first, then click 🎯 to pick an element" });
        return;
      }

      try {
        // Clear any old picker result first
        await chrome.storage.local.remove("__pickerResult");

        // Inject (safe to call multiple times due to guard in content.js)
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content.js"]
        });

        // Send start command
        await chrome.tabs.sendMessage(tab.id, { action: "startPicker" });
        sendResponse({ ok: true, tabId: tab.id });
      } catch (e) {
        sendResponse({ error: "Injection failed. Try refreshing the target page first." });
      }
    });
    return true;
  }
});

// ── Delayed picker — fires after N seconds ────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== "startDelayedPicker") return;

  const ms = Math.max(1000, (msg.seconds || 5) * 1000);
  const fireAt = Date.now() + ms;

  // Store countdown so popup can show remaining time
  chrome.storage.local.set({ __pickerCountdown: { fireAt, stepIndex: msg.stepIndex } });

  setTimeout(async () => {
    chrome.storage.local.remove("__pickerCountdown");

    // Find the active tab
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab) {
      chrome.storage.local.set({ __pickerResult: { cancelled: true, ts: Date.now() } });
      return;
    }
    const url = tab.url || "";
    if (url.startsWith("chrome://") || url.startsWith("brave://") ||
        url.startsWith("edge://")   || url.startsWith("about:")) {
      chrome.storage.local.set({ __pickerResult: { cancelled: true, ts: Date.now() } });
      return;
    }
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await chrome.tabs.sendMessage(tab.id, { action: "startPicker" });
    } catch (e) {
      chrome.storage.local.set({ __pickerResult: { cancelled: true, ts: Date.now() } });
    }
  }, ms);

  sendResponse({ ok: true, fireAt });
  return true;
});
