// Auto Clicker Pro — Popup Logic v4
// Draft persists across popup close. Delayed picker for dropdowns/hover menus.

let sequences        = [];
let buildSteps       = [];
let pickerStepIndex  = -1;
let pickerPollTimer  = null;
let pendingDelayStep = -1;   // step waiting for delayed pick to start

const DRAFT_KEY = "__acDraft__";

// ── Helpers ───────────────────────────────────────────────────────────────────

function uid() { return Math.random().toString(36).slice(2,10) + Date.now().toString(36); }

function escHtml(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

function fmtDelay(s) {
  if (s<60)   return `${s}s after launch`;
  if (s<3600) { const m=s/60; return `${Number.isInteger(m)?m:m.toFixed(1)}m after launch`; }
  const h=s/3600; return `${Number.isInteger(h)?h:h.toFixed(1)}h after launch`;
}

function fmtTime(ts) {
  if (!ts) return "never run";
  const d=Math.floor((Date.now()-ts)/1000);
  if (d<5) return "just now"; if (d<60) return `${d}s ago`;
  if (d<3600) return `${Math.floor(d/60)}m ago`;
  return `${Math.floor(d/3600)}h ago`;
}

function showToast(msg, type="success") {
  const t=document.getElementById("toast");
  t.textContent=msg; t.className=`toast ${type} show`;
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>t.classList.remove("show"), 2600);
}

function switchTab(name) {
  document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
  document.querySelectorAll(".panel").forEach(p=>p.classList.remove("active"));
  document.querySelector(`[data-tab="${name}"]`).classList.add("active");
  document.getElementById(`panel-${name}`).classList.add("active");
  if (name==="list") loadSequences();
}

// ── Draft persistence ─────────────────────────────────────────────────────────

function saveDraft() {
  chrome.storage.local.set({ [DRAFT_KEY]: {
    steps: buildSteps,
    meta: readMetaFromForm(),
    pickerStepIndex,
    activeTab: document.querySelector(".tab.active")?.dataset.tab || "list"
  }});
}

function readMetaFromForm() {
  return {
    name:       document.getElementById("seqName").value,
    urlPattern: document.getElementById("seqUrl").value,
    delayVal:   document.getElementById("delayVal").value,
    delayUnit:  document.getElementById("delayUnit").value,
    stepDelay:  document.getElementById("stepDelay").value,
  };
}

function applyMetaToForm(meta) {
  if (!meta) return;
  document.getElementById("seqName").value   = meta.name       || "";
  document.getElementById("seqUrl").value    = meta.urlPattern || "";
  document.getElementById("delayVal").value  = meta.delayVal   || "";
  document.getElementById("delayUnit").value = meta.delayUnit  || "sec";
  document.getElementById("stepDelay").value = meta.stepDelay  || "";
}

function clearDraft() {
  chrome.storage.local.remove(DRAFT_KEY);
  buildSteps=[]; pickerStepIndex=-1;
  applyMetaToForm({name:"",urlPattern:"",delayVal:"",delayUnit:"sec",stepDelay:""});
  renderSteps();
}

["seqName","seqUrl","delayVal","delayUnit","stepDelay"].forEach(id => {
  document.getElementById(id).addEventListener("input",  saveDraft);
  document.getElementById(id).addEventListener("change", saveDraft);
});

// ── Load sequences ────────────────────────────────────────────────────────────

function loadSequences() {
  chrome.runtime.sendMessage({action:"getSequences"}, (res) => {
    sequences=res?.sequences||[];
    renderList(); updateStats();
  });
}

function updateStats() {
  const active=sequences.filter(s=>s.enabled).length;
  document.getElementById("seqCount").textContent  = sequences.length;
  document.getElementById("totalSeqs").textContent  = sequences.length;
  document.getElementById("activeSeqs").textContent = active;
  document.getElementById("modalCount").textContent = sequences.length;
}

// ── Render list ───────────────────────────────────────────────────────────────

function renderList() {
  const c=document.getElementById("seqList");
  if (!sequences.length) {
    c.innerHTML=`
      <div class="empty-state">
        <div class="empty-icon">🎯</div>
        <div class="empty-title">No sequences yet</div>
        <div class="empty-desc">Click <strong>＋ New Sequence</strong> to get started.</div>
      </div>`; return;
  }
  c.innerHTML=sequences.map(s=>{
    const dotCls=!s.lastStatus?"dot-gray":s.lastStatus==="success"?"dot-green":"dot-red";
    const statusMsg=!s.lastStatus?"Not run yet"
      :s.lastStatus==="success"?`✓ Last run: ${fmtTime(s.lastRun)}`
      :`✗ ${s.lastMessage||"Error"} (${fmtTime(s.lastRun)})`;
    const stepsHtml=s.steps.map((st,i)=>`
      <div class="step-chip">
        <div class="step-chip-num">${i+1}</div>
        <div class="step-chip-text">${escHtml(st.text||st.selector)}</div>
      </div>`).join("");
    return `
    <div class="seq-card ${s.enabled?'is-enabled':'is-disabled'}">
      <div class="seq-top">
        <label class="s-toggle-wrap">
          <input type="checkbox" ${s.enabled?'checked':''} data-toggle="${s.id}"/>
          <span class="s-slider"></span>
        </label>
        <div class="seq-info">
          <div class="seq-name">${escHtml(s.name)}</div>
          <div class="seq-meta">${escHtml(s.urlPattern)} · ${s.steps.length} step(s)</div>
        </div>
        <div class="seq-badges">
          <span class="badge badge-purple">${fmtDelay(s.delaySeconds)}</span>
          <span class="badge badge-blue">${s.stepDelaySeconds||1}s/step</span>
        </div>
        <div class="seq-btns">
          <button class="icon-btn run-btn" data-run="${s.id}" title="Run now">▶</button>
          <button class="icon-btn del-btn" data-del="${s.id}" title="Delete">🗑</button>
        </div>
      </div>
      ${stepsHtml?`<div class="seq-steps">${stepsHtml}</div>`:""}
      <div class="seq-status">
        <div class="status-dot-small ${dotCls}"></div>
        <span>${escHtml(statusMsg)}</span>
      </div>
    </div>`;
  }).join("");

  c.querySelectorAll("[data-toggle]").forEach(el=>{
    el.addEventListener("change",()=>{
      chrome.runtime.sendMessage({action:"toggleSequence",id:el.dataset.toggle},()=>{
        loadSequences();
        showToast(el.checked?"✓ Enabled":"⏸ Paused",el.checked?"success":"info");
      });
    });
  });
  c.querySelectorAll("[data-run]").forEach(el=>{
    el.addEventListener("click",()=>{
      el.textContent="⏳"; el.disabled=true; showToast("Running...","info");
      chrome.runtime.sendMessage({action:"runNow",id:el.dataset.run},(res)=>{
        el.textContent="▶"; el.disabled=false;
        showToast(res?.status==="success"?"✓ Done!":"✗ "+(res?.message||"Failed"),
          res?.status==="success"?"success":"error");
        loadSequences();
      });
    });
  });
  c.querySelectorAll("[data-del]").forEach(el=>{
    el.addEventListener("click",()=>{
      chrome.runtime.sendMessage({action:"deleteSequence",id:el.dataset.del},()=>{
        loadSequences(); showToast("Deleted","error");
      });
    });
  });
}

// ── Tab nav ───────────────────────────────────────────────────────────────────

document.querySelectorAll(".tab").forEach(tab=>{
  tab.addEventListener("click",()=>{ saveDraft(); switchTab(tab.dataset.tab); });
});

// ── Clear all ─────────────────────────────────────────────────────────────────

document.getElementById("clearAllBtn").addEventListener("click",()=>{
  if (!sequences.length){showToast("Nothing to clear","info");return;}
  document.getElementById("clearAllModal").classList.add("show");
});
document.getElementById("cancelClear").addEventListener("click",()=>
  document.getElementById("clearAllModal").classList.remove("show"));
document.getElementById("confirmClear").addEventListener("click",()=>{
  chrome.runtime.sendMessage({action:"saveSequences",sequences:[]},()=>{
    document.getElementById("clearAllModal").classList.remove("show");
    loadSequences(); showToast("🗑 Cleared","error");
  });
});
document.getElementById("clearAllModal").addEventListener("click",e=>{
  if (e.target===e.currentTarget) e.currentTarget.classList.remove("show");
});

// ── Steps builder ─────────────────────────────────────────────────────────────

document.getElementById("addStepBtn").addEventListener("click",()=>{
  buildSteps.push({id:uid(),selector:"",text:""});
  renderSteps(); saveDraft();
});

function renderSteps() {
  const list=document.getElementById("stepsList");
  if (!buildSteps.length) {
    list.innerHTML=`<div style="text-align:center;padding:16px;font-size:12px;color:var(--text-muted)">
      No steps yet — add a step then use 🎯 to pick elements on the page</div>`;
    return;
  }
  list.innerHTML=buildSteps.map((step,i)=>`
    <div class="step-row ${pickerStepIndex===i?'picking':''}" data-step="${i}">
      <div class="step-num">${i+1}</div>
      <div class="step-selector-text ${step.selector?'':'empty'}">
        ${step.selector?escHtml(step.selector):'Click 🎯 to pick an element'}
      </div>
      ${step.text?`<div class="step-text-preview" title="${escHtml(step.text)}">"${escHtml(step.text)}"</div>`:""}
      <div class="step-btns" id="stepBtns${i}">
        <button class="step-icon-btn pick-btn" data-pick="${i}" title="Pick now">
          ${pickerStepIndex===i?'⏳':'🎯'}
        </button>
        <button class="step-icon-btn pick-btn" data-delaypick="${i}" title="Delayed pick (for dropdowns)" style="font-size:11px;padding:2px 4px;">
          ⏱
        </button>
        <button class="step-icon-btn del-step" data-delstep="${i}" title="Remove step">✕</button>
      </div>
    </div>`).join("");

  // Instant pick
  list.querySelectorAll("[data-pick]").forEach(el=>{
    el.addEventListener("click",()=>startPickerForStep(parseInt(el.dataset.pick)));
  });

  // Delayed pick — opens the countdown modal
  list.querySelectorAll("[data-delaypick]").forEach(el=>{
    el.addEventListener("click",()=>openDelayModal(parseInt(el.dataset.delaypick)));
  });

  // Delete step
  list.querySelectorAll("[data-delstep]").forEach(el=>{
    el.addEventListener("click",()=>{
      const idx=parseInt(el.dataset.delstep);
      buildSteps.splice(idx,1);
      if (pickerStepIndex===idx){stopPolling();pickerStepIndex=-1;}
      renderSteps(); saveDraft();
    });
  });
}

// ── Instant picker ────────────────────────────────────────────────────────────

function startPickerForStep(idx) {
  stopPolling(); pickerStepIndex=idx;
  renderSteps(); saveDraft(); showBanner(true);

  chrome.runtime.sendMessage({action:"startPicker"},(res)=>{
    if (chrome.runtime.lastError||res?.error) {
      showToast(res?.error||"Picker failed — make sure a real webpage is open","error");
      pickerStepIndex=-1; renderSteps(); saveDraft(); showBanner(false); return;
    }
    startPolling();
  });
}

// ── Delayed picker ────────────────────────────────────────────────────────────
// 1. User clicks ⏱ → modal opens, user sets seconds
// 2. User clicks "Start Countdown" → popup window.close()
// 3. Background counts down, then injects picker into the active tab
// 4. Popup polls storage on next open; result flows in normally

function openDelayModal(stepIdx) {
  pendingDelayStep=stepIdx;
  document.getElementById("delayPickModal").classList.add("show");
  document.getElementById("delayPickSecs").focus();
  document.getElementById("delayPickSecs").select();
}

document.getElementById("cancelDelayPick").addEventListener("click",()=>{
  document.getElementById("delayPickModal").classList.remove("show");
  pendingDelayStep=-1;
});

document.getElementById("startDelayPick").addEventListener("click",()=>{
  const secs=Math.max(1,Math.min(30,parseInt(document.getElementById("delayPickSecs").value)||5));
  document.getElementById("delayPickModal").classList.remove("show");

  if (pendingDelayStep<0) return;
  pickerStepIndex=pendingDelayStep;
  pendingDelayStep=-1;

  // Save draft with pickerStepIndex so popup restores after it reopens
  saveDraft();

  // Tell background to start a delayed inject
  chrome.runtime.sendMessage({action:"startDelayedPicker", seconds:secs, stepIndex:pickerStepIndex},(res)=>{
    if (res?.error) { showToast(res.error,"error"); return; }
    // Close the popup — user needs to switch to page and open dropdown
    window.close();
  });
});

// Countdown display: background sends storage updates with countdown
function showBanner(show) {
  const b=document.getElementById("pickerBanner");
  show?b.classList.add("show"):b.classList.remove("show");
}

// ── Storage polling for picker result ─────────────────────────────────────────

function startPolling() {
  stopPolling();
  pickerPollTimer=setInterval(checkPickerResult,400);
  setTimeout(()=>{
    if (pickerStepIndex>=0){
      stopPolling(); pickerStepIndex=-1;
      renderSteps(); saveDraft(); showBanner(false);
      showToast("Picker timed out","error");
    }
  },90000);
}

function stopPolling() {
  if (pickerPollTimer){clearInterval(pickerPollTimer);pickerPollTimer=null;}
}

function checkPickerResult() {
  chrome.storage.local.get("__pickerResult",(data)=>{
    const result=data.__pickerResult;
    if (!result) return;
    chrome.storage.local.remove("__pickerResult");
    stopPolling(); showBanner(false);

    if (result.cancelled){
      pickerStepIndex=-1; renderSteps(); saveDraft();
      showToast("Picker cancelled","info"); return;
    }
    if (pickerStepIndex>=0&&pickerStepIndex<buildSteps.length){
      buildSteps[pickerStepIndex].selector=result.selector||"";
      buildSteps[pickerStepIndex].text    =result.text||"";
      const n=pickerStepIndex+1; pickerStepIndex=-1;
      renderSteps(); saveDraft();
      showToast(`✓ Step ${n} captured!`,"success");
    } else {
      pickerStepIndex=-1; renderSteps(); saveDraft();
    }
  });
}

// ── Save sequence ─────────────────────────────────────────────────────────────

document.getElementById("saveSeqBtn").addEventListener("click",()=>{
  const name      =document.getElementById("seqName").value.trim();
  const urlPattern=document.getElementById("seqUrl").value.trim();
  const delayVal  =parseFloat(document.getElementById("delayVal").value)||30;
  const delayUnit =document.getElementById("delayUnit").value;
  const stepDelay =parseFloat(document.getElementById("stepDelay").value)||1;

  if (!name)              {showToast("Enter a sequence name","error");return;}
  if (!urlPattern)        {showToast("Enter a target URL pattern","error");return;}
  if (!buildSteps.length) {showToast("Add at least one step","error");return;}
  const unpicked=buildSteps.findIndex(s=>!s.selector);
  if (unpicked>=0)        {showToast(`Step ${unpicked+1}: pick an element first`,"error");return;}

  let delaySec=delayVal;
  if (delayUnit==="min") delaySec*=60;
  if (delayUnit==="hr")  delaySec*=3600;

  const newSeq={
    id:uid(), name, urlPattern,
    delaySeconds:Math.max(5,Math.round(delaySec)),
    stepDelaySeconds:Math.max(0.5,stepDelay),
    steps:buildSteps.map(s=>({...s})),
    enabled:true, lastRun:null, lastStatus:null, lastMessage:null
  };

  chrome.runtime.sendMessage({action:"getSequences"},(res)=>{
    const updated=[...(res?.sequences||[]),newSeq];
    chrome.runtime.sendMessage({action:"saveSequences",sequences:updated},()=>{
      showToast("✓ Sequence saved!");
      clearDraft(); switchTab("list");
    });
  });
});

// ── Init — restore draft + check for pending picker result ────────────────────

chrome.storage.local.get([DRAFT_KEY,"__pickerResult","__pickerCountdown"],(data)=>{
  const draft=data[DRAFT_KEY];

  if (draft) {
    buildSteps=draft.steps||[];
    applyMetaToForm(draft.meta||{});

    if (draft.pickerStepIndex>=0) {
      pickerStepIndex=draft.pickerStepIndex;
      // If there's already a result waiting, grab it
      if (data.__pickerResult) {
        // handled below
      } else {
        // Still waiting — show banner and resume poll
        showBanner(true);
        startPolling();
      }
    }
    if (draft.activeTab && draft.activeTab!=="list") {
      switchTab(draft.activeTab);
    }
  }

  // Check if a countdown is still running
  if (data.__pickerCountdown) {
    const remaining=data.__pickerCountdown.fireAt - Date.now();
    if (remaining>0) {
      showBanner(true);
      document.getElementById("pickerBanner").textContent =
        `⏱ Picker fires in ~${Math.ceil(remaining/1000)}s — switch to your page and open the dropdown`;
    }
  }

  if (data.__pickerResult) {
    checkPickerResult();
  }

  renderSteps();
  loadSequences();
});
