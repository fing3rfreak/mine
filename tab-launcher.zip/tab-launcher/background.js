// Tab Launcher — Background Service Worker
// On browser start: close previous session tabs, open saved URLs

const SESSION_KEY = "launcher_session_ids";

// ── Startup ───────────────────────────────────────────────────────────────────

chrome.runtime.onStartup.addListener(() => {
  launchTabs();
});

chrome.runtime.onInstalled.addListener(() => {
  // Just initialize storage defaults on install, don't open tabs
  chrome.storage.local.get("links", ({ links }) => {
    if (!links) chrome.storage.local.set({ links: [] });
  });
});

// ── Core Logic ────────────────────────────────────────────────────────────────

async function launchTabs() {
  const { links = [], enabled = true } = await chrome.storage.local.get(["links", "enabled"]);

  if (!enabled || links.length === 0) return;

  // Step 1: Close previous session tabs (tabs opened by us last time)
  await closePreviousSessionTabs();

  // Step 2: Get the current "new tab" page that Chrome opens on start
  // Close it so we don't leave a blank tab behind
  const allTabs = await chrome.tabs.query({});
  const blankTabs = allTabs.filter(t =>
    t.url === "chrome://newtab/" ||
    t.url === "about:blank" ||
    t.url === ""
  );

  // Step 3: Open all saved links
  const newTabIds = [];
  for (const link of links) {
    if (!link.url || !link.enabled) continue;
    try {
      const tab = await chrome.tabs.create({ url: link.url, active: false });
      newTabIds.push(tab.id);
    } catch (e) {
      console.warn("Could not open tab:", link.url, e);
    }
  }

  // Step 4: Close blank tabs after our tabs are open
  for (const t of blankTabs) {
    try { await chrome.tabs.remove(t.id); } catch {}
  }

  // Step 5: Focus first opened tab
  if (newTabIds.length > 0) {
    try { await chrome.tabs.update(newTabIds[0], { active: true }); } catch {}
  }

  // Step 6: Save this session's tab IDs so we can close them next time
  await chrome.storage.local.set({ [SESSION_KEY]: newTabIds });
  await chrome.storage.local.set({ lastLaunch: Date.now(), lastLaunchCount: newTabIds.length });

  console.log(`[Tab Launcher] Opened ${newTabIds.length} tab(s)`);
}

async function closePreviousSessionTabs() {
  const data = await chrome.storage.local.get(SESSION_KEY);
  const prevIds = data[SESSION_KEY] || [];
  if (!prevIds.length) return;

  // Only close tabs that still exist and match our saved IDs
  const allTabs = await chrome.tabs.query({});
  const existingIds = new Set(allTabs.map(t => t.id));

  for (const id of prevIds) {
    if (existingIds.has(id)) {
      try { await chrome.tabs.remove(id); } catch {}
    }
  }

  await chrome.storage.local.remove(SESSION_KEY);
}

// ── Message Handler ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === "getStatus") {
    chrome.storage.local.get(["links", "enabled", "lastLaunch", "lastLaunchCount"], (data) => {
      sendResponse(data);
    });
    return true;
  }

  if (msg.action === "saveLinks") {
    chrome.storage.local.set({ links: msg.links }, () => sendResponse({ success: true }));
    return true;
  }

  if (msg.action === "setEnabled") {
    chrome.storage.local.set({ enabled: msg.enabled }, () => sendResponse({ success: true }));
    return true;
  }

  if (msg.action === "launchNow") {
    launchTabs().then(() => sendResponse({ success: true }));
    return true;
  }
});
