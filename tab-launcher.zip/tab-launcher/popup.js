// Tab Launcher — Popup Logic

let links = [];
let globalEnabled = true;

// ── Helpers ───────────────────────────────────────────────────────────────────

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function escHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function getDomain(url) {
  try { return new URL(url).hostname.replace("www.", ""); }
  catch { return url; }
}

function getFaviconUrl(url) {
  try {
    const origin = new URL(url).origin;
    return `https://www.google.com/s2/favicons?domain=${origin}&sz=32`;
  } catch { return null; }
}

function fmtTime(ts) {
  if (!ts) return "never";
  const d = Math.floor((Date.now() - ts) / 1000);
  if (d < 5)    return "just now";
  if (d < 60)   return `${d}s ago`;
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  return `${Math.floor(d / 3600)}h ago`;
}

function showToast(msg, type = "success") {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = `toast ${type} show`;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 2400);
}

function switchToTab(name) {
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
  document.querySelector(`[data-tab="${name}"]`).classList.add("active");
  document.getElementById(`panel-${name}`).classList.add("active");
  if (name === "list") loadData();
}

function saveLinks(newLinks, cb) {
  chrome.runtime.sendMessage({ action: "saveLinks", links: newLinks }, () => {
    links = newLinks;
    renderList();
    updateStats();
    if (cb) cb();
  });
}

// ── Load ──────────────────────────────────────────────────────────────────────

function loadData() {
  chrome.runtime.sendMessage({ action: "getStatus" }, (res) => {
    links = res?.links || [];
    globalEnabled = res?.enabled ?? true;
    renderList();
    updateStats();
    updateStatusBar(res);
    updateEnableToggle();
  });
}

function updateStats() {
  const enabled = links.filter(l => l.enabled).length;
  document.getElementById("totalCount").textContent = links.length;
  document.getElementById("enabledCount").textContent = enabled;
  document.getElementById("modalCount").textContent = links.length;
}

function updateStatusBar(res) {
  const dot  = document.getElementById("statusDot");
  const text = document.getElementById("statusText");
  const enabled = globalEnabled && links.some(l => l.enabled);
  dot.className = "status-dot" + (enabled ? " on" : "");
  if (!globalEnabled) {
    text.textContent = "Launcher disabled — tabs will not open on start";
  } else if (links.length === 0) {
    text.textContent = "No tabs saved yet";
  } else {
    const count = links.filter(l => l.enabled).length;
    const last  = res?.lastLaunch ? `Last launch: ${fmtTime(res.lastLaunch)}` : "Not launched yet this session";
    text.textContent = `${count} tab(s) will open on start · ${last}`;
  }
}

function updateEnableToggle() {
  const toggle = document.getElementById("enableToggle");
  const label  = document.getElementById("enableLabel");
  toggle.checked  = globalEnabled;
  label.textContent = globalEnabled ? "ON" : "OFF";
}

// ── Render List ───────────────────────────────────────────────────────────────

function renderList() {
  const container = document.getElementById("linksList");

  if (links.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🚀</div>
        <div class="empty-title">No tabs saved yet</div>
        <div class="empty-desc">
          Use <strong>Add URL</strong> to add tabs one by one,<br>
          or <strong>Import</strong> to load from a file.
        </div>
      </div>`;
    return;
  }

  container.innerHTML = links.map(l => {
    const favicon = getFaviconUrl(l.url);
    const faviconHtml = favicon
      ? `<img src="${escHtml(favicon)}" onerror="this.style.display='none'" />`
      : `🔗`;
    return `
    <div class="link-card ${l.enabled ? 'is-enabled' : 'is-disabled'}" data-id="${l.id}">
      <label class="c-toggle-wrap">
        <input type="checkbox" ${l.enabled ? 'checked' : ''} data-toggle="${l.id}" />
        <span class="c-slider"></span>
      </label>
      <div class="link-favicon">${faviconHtml}</div>
      <div class="link-info">
        <div class="link-label">${escHtml(l.label || getDomain(l.url))}</div>
        <div class="link-url">${escHtml(l.url)}</div>
      </div>
      <div class="link-btns">
        <button class="action-btn btn-open" data-open="${escHtml(l.url)}" title="Open now">↗</button>
        <button class="action-btn btn-del" data-delete="${l.id}" title="Remove">🗑</button>
      </div>
    </div>`;
  }).join("");

  // Toggle individual link
  container.querySelectorAll("[data-toggle]").forEach(el => {
    el.addEventListener("change", () => {
      const updated = links.map(l =>
        l.id === el.dataset.toggle ? { ...l, enabled: el.checked } : l
      );
      saveLinks(updated);
      showToast(el.checked ? "✓ Tab enabled" : "⏸ Tab disabled", el.checked ? "success" : "info");
    });
  });

  // Open in new tab now
  container.querySelectorAll("[data-open]").forEach(el => {
    el.addEventListener("click", () => {
      chrome.tabs.create({ url: el.dataset.open });
    });
  });

  // Delete single
  container.querySelectorAll("[data-delete]").forEach(el => {
    el.addEventListener("click", () => {
      const updated = links.filter(l => l.id !== el.dataset.delete);
      saveLinks(updated, () => showToast("Removed", "error"));
    });
  });
}

// ── Global Enable Toggle ──────────────────────────────────────────────────────

document.getElementById("enableToggle").addEventListener("change", (e) => {
  globalEnabled = e.target.checked;
  document.getElementById("enableLabel").textContent = globalEnabled ? "ON" : "OFF";
  chrome.runtime.sendMessage({ action: "setEnabled", enabled: globalEnabled }, () => {
    updateStatusBar({});
    showToast(globalEnabled ? "✓ Launcher enabled" : "⏸ Launcher disabled", globalEnabled ? "success" : "info");
  });
});

// ── Tab Nav ───────────────────────────────────────────────────────────────────

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => switchToTab(tab.dataset.tab));
});

// ── Launch Now ────────────────────────────────────────────────────────────────

document.getElementById("launchNowBtn").addEventListener("click", () => {
  if (links.filter(l => l.enabled).length === 0) {
    showToast("No enabled tabs to launch", "info");
    return;
  }
  chrome.runtime.sendMessage({ action: "launchNow" }, () => {
    showToast("🚀 Launched!", "success");
    setTimeout(loadData, 600);
  });
});

// ── Clear All ─────────────────────────────────────────────────────────────────

document.getElementById("deleteAllBtn").addEventListener("click", () => {
  if (links.length === 0) { showToast("Nothing to clear", "info"); return; }
  document.getElementById("deleteAllModal").classList.add("show");
});

document.getElementById("cancelDeleteAll").addEventListener("click", () => {
  document.getElementById("deleteAllModal").classList.remove("show");
});

document.getElementById("confirmDeleteAll").addEventListener("click", () => {
  saveLinks([], () => {
    document.getElementById("deleteAllModal").classList.remove("show");
    showToast("🗑 All tabs cleared", "error");
  });
});

document.getElementById("deleteAllModal").addEventListener("click", (e) => {
  if (e.target === e.currentTarget) e.currentTarget.classList.remove("show");
});

// ── Add Single ────────────────────────────────────────────────────────────────

document.getElementById("addBtn").addEventListener("click", () => {
  const label = document.getElementById("addLabel").value.trim();
  let url     = document.getElementById("addUrl").value.trim();

  if (!url) { showToast("Enter a URL", "error"); return; }

  // Auto-add https:// if missing
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;

  try { new URL(url); } catch {
    showToast("Invalid URL", "error"); return;
  }

  const newLink = {
    id: uid(),
    label: label || getDomain(url),
    url,
    enabled: true
  };

  const updated = [...links, newLink];
  saveLinks(updated, () => {
    showToast("✓ Tab added");
    document.getElementById("addLabel").value = "";
    document.getElementById("addUrl").value = "";
    switchToTab("list");
  });
});

// ── Parse & Import ────────────────────────────────────────────────────────────

function parseLines(text) {
  return text.split("\n")
    .map(l => l.trim())
    .filter(l => l && !l.startsWith("#"))
    .map(line => {
      const parts = line.split(",").map(p => p.trim());
      let url   = parts[0];
      const label = parts[1] || "";

      if (!url) return null;
      if (!/^https?:\/\//i.test(url)) url = "https://" + url;

      try { new URL(url); } catch { return null; }

      return {
        id: uid(),
        label: label || getDomain(url),
        url,
        enabled: true
      };
    })
    .filter(Boolean);
}

function doImport(text) {
  const newLinks = parseLines(text);
  if (!newLinks.length) { showToast("No valid URLs found", "error"); return; }

  const updated = [...links, ...newLinks];
  saveLinks(updated, () => {
    showToast(`✓ Imported ${newLinks.length} tab(s)`);
    document.getElementById("pasteArea").value = "";
    switchToTab("list");
  });
}

document.getElementById("importBtn").addEventListener("click", () => {
  const text = document.getElementById("pasteArea").value;
  if (!text.trim()) { showToast("Nothing to import", "error"); return; }
  doImport(text);
});

document.getElementById("fileInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => doImport(ev.target.result);
  reader.readAsText(file);
  e.target.value = "";
});

const dropZone = document.getElementById("dropZone");
dropZone.addEventListener("dragover", (e) => { e.preventDefault(); dropZone.classList.add("dragover"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
dropZone.addEventListener("drop", (e) => {
  e.preventDefault(); dropZone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => doImport(ev.target.result);
  reader.readAsText(file);
});

// ── Init ──────────────────────────────────────────────────────────────────────

loadData();
