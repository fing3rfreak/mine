// Auto Refresher Pro — Background Service Worker
// Each URL entry gets its own named alarm for individual intervals

const ALARM_PREFIX = "refresher::";

// ── Startup / Install ─────────────────────────────────────────────────────────

chrome.runtime.onStartup.addListener(() => initAll());
chrome.runtime.onInstalled.addListener(() => initAll());

async function initAll() {
  const { entries = [] } = await chrome.storage.local.get("entries");
  // Clear all existing alarms first
  await chrome.alarms.clearAll();
  // Re-schedule enabled entries
  for (const entry of entries) {
    if (entry.enabled) scheduleAlarm(entry);
  }
}

// ── Alarm Scheduling ──────────────────────────────────────────────────────────

function alarmName(id) {
  return ALARM_PREFIX + id;
}

function scheduleAlarm(entry) {
  const mins = entry.intervalSeconds / 60;
  chrome.alarms.create(alarmName(entry.id), {
    delayInMinutes: mins,
    periodInMinutes: mins
  });
}

function clearAlarm(id) {
  chrome.alarms.clear(alarmName(id));
}

// ── Alarm Handler ─────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith(ALARM_PREFIX)) return;
  const id = alarm.name.slice(ALARM_PREFIX.length);

  const { entries = [] } = await chrome.storage.local.get("entries");
  const entry = entries.find(e => e.id === id);
  if (!entry || !entry.enabled) return;

  await refreshTabsForEntry(entry);

  // Update last refresh time
  const updated = entries.map(e =>
    e.id === id ? { ...e, lastRefresh: Date.now(), refreshCount: (e.refreshCount || 0) + 1 } : e
  );
  await chrome.storage.local.set({ entries: updated });
});

// ── Tab Refresher ─────────────────────────────────────────────────────────────

async function refreshTabsForEntry(entry) {
  const tabs = await chrome.tabs.query({});
  let count = 0;

  for (const tab of tabs) {
    if (!tab.url) continue;
    if (tabMatchesEntry(tab.url, entry)) {
      try {
        await chrome.tabs.reload(tab.id);
        count++;
      } catch (e) {
        console.warn("Could not reload tab:", tab.id, e);
      }
    }
  }
  console.log(`[AutoRefresher] "${entry.label}" → refreshed ${count} tab(s)`);
  return count;
}

function tabMatchesEntry(tabUrl, entry) {
  const pattern = entry.pattern.trim();
  if (!pattern) return false;

  if (entry.matchType === "exact") {
    // Normalize: strip trailing slash for comparison
    const normalize = u => u.replace(/\/$/, "").toLowerCase();
    return normalize(tabUrl) === normalize(pattern);
  } else if (entry.matchType === "partial") {
    return tabUrl.toLowerCase().includes(pattern.toLowerCase());
  } else {
    // "both" — try exact first, then partial
    const normalize = u => u.replace(/\/$/, "").toLowerCase();
    return normalize(tabUrl) === normalize(pattern) ||
           tabUrl.toLowerCase().includes(pattern.toLowerCase());
  }
}

// ── Message Handler ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // Get all entries
  if (msg.action === "getEntries") {
    chrome.storage.local.get("entries", ({ entries = [] }) => {
      sendResponse({ entries });
    });
    return true;
  }

  // Save all entries (bulk replace)
  if (msg.action === "saveEntries") {
    const entries = msg.entries;
    chrome.alarms.clearAll(async () => {
      await chrome.storage.local.set({ entries });
      for (const e of entries) {
        if (e.enabled) scheduleAlarm(e);
      }
      sendResponse({ success: true });
    });
    return true;
  }

  // Toggle a single entry
  if (msg.action === "toggleEntry") {
    chrome.storage.local.get("entries", ({ entries = [] }) => {
      const updated = entries.map(e => {
        if (e.id !== msg.id) return e;
        const newEnabled = !e.enabled;
        if (newEnabled) scheduleAlarm({ ...e, enabled: true });
        else clearAlarm(e.id);
        return { ...e, enabled: newEnabled };
      });
      chrome.storage.local.set({ entries: updated }, () => sendResponse({ success: true }));
    });
    return true;
  }

  // Refresh now (manual trigger)
  if (msg.action === "refreshNow") {
    chrome.storage.local.get("entries", async ({ entries = [] }) => {
      const entry = entries.find(e => e.id === msg.id);
      if (!entry) { sendResponse({ count: 0 }); return; }
      const count = await refreshTabsForEntry(entry);
      const updated = entries.map(e =>
        e.id === msg.id ? { ...e, lastRefresh: Date.now(), refreshCount: (e.refreshCount || 0) + count } : e
      );
      await chrome.storage.local.set({ entries: updated });
      sendResponse({ count });
    });
    return true;
  }

  // Delete entry
  if (msg.action === "deleteEntry") {
    chrome.storage.local.get("entries", ({ entries = [] }) => {
      clearAlarm(msg.id);
      const updated = entries.filter(e => e.id !== msg.id);
      chrome.storage.local.set({ entries: updated }, () => sendResponse({ success: true }));
    });
    return true;
  }
});
