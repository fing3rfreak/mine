// Auto Refresher Pro — Popup Logic

let entries = [];

// ── Helpers ──────────────────────────────────────────────────────────────────

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function fmtInterval(seconds) {
  if (seconds < 60) return `${seconds}s`;
  const m = seconds / 60;
  return Number.isInteger(m) ? `${m}m` : `${m.toFixed(1)}m`;
}

function fmtTime(ts) {
  if (!ts) return "never";
  const d = Math.floor((Date.now() - ts) / 1000);
  if (d < 5) return "just now";
  if (d < 60) return `${d}s ago`;
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  return `${Math.floor(d / 3600)}h ago`;
}

function showToast(msg, type = "success") {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = `toast ${type} show`;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 2200);
}

function matchLabel(type) {
  return { exact: "exact", partial: "~match", both: "≈both" }[type] || type;
}

// ── Load & Render ─────────────────────────────────────────────────────────────

function loadEntries() {
  chrome.runtime.sendMessage({ action: "getEntries" }, (res) => {
    entries = res?.entries || [];
    renderList();
    updateStats();
  });
}

function updateStats() {
  const active = entries.filter(e => e.enabled).length;
  document.getElementById("activeCount").textContent = active;
}

function renderList() {
  const container = document.getElementById("entriesList");

  if (entries.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="big">🔗</div>
        No URLs configured yet.<br>
        Use <strong>Add URL</strong> or <strong>Import File</strong><br>to get started.
      </div>`;
    return;
  }

  container.innerHTML = entries.map(e => `
    <div class="entry-card ${e.enabled ? 'enabled' : 'disabled'}" data-id="${e.id}">
      <div class="entry-top">
        <label class="entry-toggle">
          <input type="checkbox" ${e.enabled ? 'checked' : ''} data-toggle="${e.id}" />
          <span class="e-slider"></span>
        </label>
        <div class="entry-info">
          <div class="entry-label">${escHtml(e.label || e.pattern)}</div>
          <div class="entry-pattern">${escHtml(e.pattern)}</div>
        </div>
        <div class="entry-meta">
          <span class="badge badge-interval">${fmtInterval(e.intervalSeconds)}</span>
          <span class="badge badge-match">${matchLabel(e.matchType)}</span>
        </div>
        <div class="entry-actions">
          <button class="icon-btn" data-refresh="${e.id}" title="Refresh now">⟳</button>
          <button class="icon-btn delete" data-delete="${e.id}" title="Delete">✕</button>
        </div>
      </div>
      <div class="entry-bottom">
        <span class="last-refresh-info">Last: ${fmtTime(e.lastRefresh)}</span>
        <span class="refresh-count">${e.refreshCount || 0} refreshes</span>
      </div>
    </div>
  `).join("");

  // Bind toggle
  container.querySelectorAll("[data-toggle]").forEach(el => {
    el.addEventListener("change", () => {
      chrome.runtime.sendMessage({ action: "toggleEntry", id: el.dataset.toggle }, () => {
        loadEntries();
        showToast(el.checked ? "✓ Enabled" : "⏸ Paused", el.checked ? "success" : "info");
      });
    });
  });

  // Bind refresh now
  container.querySelectorAll("[data-refresh]").forEach(el => {
    el.addEventListener("click", () => {
      chrome.runtime.sendMessage({ action: "refreshNow", id: el.dataset.refresh }, (res) => {
        showToast(`⟳ Refreshed ${res?.count || 0} tab(s)`, "info");
        loadEntries();
      });
    });
  });

  // Bind delete
  container.querySelectorAll("[data-delete]").forEach(el => {
    el.addEventListener("click", () => {
      chrome.runtime.sendMessage({ action: "deleteEntry", id: el.dataset.delete }, () => {
        loadEntries();
        showToast("🗑 Removed", "error");
      });
    });
  });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ── Tab Switching ─────────────────────────────────────────────────────────────

document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("panel-" + tab.dataset.tab).classList.add("active");
    if (tab.dataset.tab === "list") loadEntries();
  });
});

// ── Add Entry ─────────────────────────────────────────────────────────────────

document.getElementById("addBtn").addEventListener("click", () => {
  const label = document.getElementById("addLabel").value.trim();
  const pattern = document.getElementById("addPattern").value.trim();
  const matchType = document.getElementById("addMatchType").value;
  const val = parseFloat(document.getElementById("addIntervalVal").value) || 30;
  const unit = document.getElementById("addIntervalUnit").value;

  if (!pattern) { showToast("Enter a URL or pattern", "error"); return; }

  const seconds = unit === "min" ? Math.round(val * 60) : Math.round(val);
  if (seconds < 5) { showToast("Min interval is 5 seconds", "error"); return; }

  const newEntry = {
    id: uid(),
    label: label || pattern,
    pattern,
    matchType,
    intervalSeconds: seconds,
    enabled: true,
    lastRefresh: null,
    refreshCount: 0
  };

  chrome.runtime.sendMessage({ action: "getEntries" }, (res) => {
    const updated = [...(res?.entries || []), newEntry];
    chrome.runtime.sendMessage({ action: "saveEntries", entries: updated }, () => {
      showToast("✓ Added & started");
      document.getElementById("addLabel").value = "";
      document.getElementById("addPattern").value = "";
      document.getElementById("addIntervalVal").value = "";
      // Switch to list
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      document.querySelector("[data-tab='list']").classList.add("active");
      document.getElementById("panel-list").classList.add("active");
      loadEntries();
    });
  });
});

// ── Parse lines helper ────────────────────────────────────────────────────────

function parseLines(text) {
  return text.split("\n")
    .map(l => l.trim())
    .filter(l => l && !l.startsWith("#"))
    .map(line => {
      const parts = line.split(",").map(p => p.trim());
      const pattern = parts[0];
      if (!pattern) return null;

      const intervalRaw = parseFloat(parts[1]) || 30;
      const unit = (parts[2] || "sec").toLowerCase().startsWith("m") ? "min" : "sec";
      const seconds = unit === "min" ? Math.round(intervalRaw * 60) : Math.round(intervalRaw);
      const matchType = (parts[3] || "both").toLowerCase();
      const validMatch = ["exact", "partial", "both"].includes(matchType) ? matchType : "both";
      const label = parts[4] || pattern;

      return {
        id: uid(),
        label,
        pattern,
        matchType: validMatch,
        intervalSeconds: Math.max(5, seconds),
        enabled: true,
        lastRefresh: null,
        refreshCount: 0
      };
    })
    .filter(Boolean);
}

// ── Import ────────────────────────────────────────────────────────────────────

document.getElementById("importBtn").addEventListener("click", () => {
  const text = document.getElementById("pasteArea").value;
  if (!text.trim()) { showToast("Nothing to import", "error"); return; }
  doImport(text);
});

function doImport(text) {
  const newEntries = parseLines(text);
  if (!newEntries.length) { showToast("No valid entries found", "error"); return; }

  chrome.runtime.sendMessage({ action: "getEntries" }, (res) => {
    const existing = res?.entries || [];
    const merged = [...existing, ...newEntries];
    chrome.runtime.sendMessage({ action: "saveEntries", entries: merged }, () => {
      showToast(`✓ Imported ${newEntries.length} URL(s)`);
      document.getElementById("pasteArea").value = "";
      // Switch to list
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      document.querySelector("[data-tab='list']").classList.add("active");
      document.getElementById("panel-list").classList.add("active");
      loadEntries();
    });
  });
}

// File import
document.getElementById("fileInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => doImport(ev.target.result);
  reader.readAsText(file);
  e.target.value = "";
});

// Drag over styling
const dropZone = document.getElementById("dropZone");
dropZone.addEventListener("dragover", (e) => { e.preventDefault(); dropZone.classList.add("dragover"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
dropZone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropZone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => doImport(ev.target.result);
  reader.readAsText(file);
});

// ── Auto-refresh display ──────────────────────────────────────────────────────

setInterval(() => {
  // Only re-render if list tab is active (avoid layout jumps)
  if (document.querySelector("[data-tab='list']").classList.contains("active")) {
    loadEntries();
  }
}, 4000);

// ── Init ──────────────────────────────────────────────────────────────────────

loadEntries();
